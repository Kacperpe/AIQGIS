import html
import json
import threading

from qgis.PyQt.QtCore import QSettings, QThread, Qt, pyqtSignal
from qgis.PyQt.QtGui import QTextCursor
from qgis.PyQt.QtWidgets import (
    QAction, QDockWidget, QHBoxLayout, QInputDialog,
    QLabel, QLineEdit, QPushButton, QTextEdit,
    QVBoxLayout, QWidget
)

from .claude_client import AIClient
from .qgis_tools import QGISToolExecutor


def html_escape_code(text):
    code = text.strip("\n")
    if "\n" in code:
        first_line, rest = code.split("\n", 1)
        if first_line.isidentifier():
            code = rest
    return html.escape(code)


class Worker(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    status = pyqtSignal(str)
    tool_requested = pyqtSignal(str, dict)

    def __init__(self, client, message, tools):
        super().__init__()
        self.client = client
        self.message = message
        self.tools = tools or []
        self._tool_event = threading.Event()
        self._tool_result = None

    def run(self):
        try:
            reply = self.client.chat(
                self.message,
                tools=self.tools,
                tool_executor=self._execute_tool,
                status_callback=self.status.emit,
            )
            self.finished.emit(reply)
        except Exception as exc:
            self.error.emit(str(exc))

    def _execute_tool(self, tool_name, tool_args):
        self._tool_result = None
        self._tool_event.clear()
        self.tool_requested.emit(tool_name, tool_args)
        if not self._tool_event.wait(300):
            raise Exception(f"Przekroczono czas oczekiwania na narzedzie: {tool_name}")
        return self._tool_result

    def set_tool_result(self, result):
        self._tool_result = result
        self._tool_event.set()


class AIPanel(QWidget):
    def __init__(self, plugin, provider, provider_settings):
        super().__init__()
        self.plugin = plugin
        self.iface = plugin.iface
        self.provider = provider
        self.provider_settings = provider_settings
        self.client = AIClient(provider, provider_settings)
        self.tool_executor = QGISToolExecutor(self.iface)
        self.worker = None
        self._build_ui()
        self._welcome()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        self.chat = QTextEdit()
        self.chat.setReadOnly(True)
        self.chat.setStyleSheet(
            "QTextEdit { background:#1e1e1e; color:#d4d4d4; "
            "font-family: Consolas, monospace; font-size:12px; }"
        )
        root.addWidget(self.chat)

        btn_row = QHBoxLayout()
        for label, slot in [
            ("Provider", self._change_provider),
            ("Ustawienia", self._change_settings),
            ("Warstwy", self._inject_layers),
            ("CRS", self._inject_crs),
            ("Wyczysc", self._clear),
        ]:
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            btn_row.addWidget(btn)
        root.addLayout(btn_row)

        send_row = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setPlaceholderText("Zadaj pytanie o dane GIS...")
        self.input.returnPressed.connect(self._send)
        self.send_btn = QPushButton("Wyslij")
        self.send_btn.setFixedWidth(90)
        self.send_btn.clicked.connect(self._send)
        send_row.addWidget(self.input)
        send_row.addWidget(self.send_btn)
        root.addLayout(send_row)

        self.status = QLabel("")
        self.status.setStyleSheet("color: gray; font-size: 10px;")
        root.addWidget(self.status)

    def _welcome(self):
        provider_name = AIClient.provider_label(self.provider)
        tools_state = (
            "Toole QGIS aktywne."
            if self.client.supports_tools()
            else "Toole QGIS nieaktywne dla tego providera."
        )
        self._append(
            "system",
            (
                f"AI Assistant gotowy. Provider: {provider_name}. "
                f"Model: {self.client.model}. {tools_state} "
                "Kliknij Warstwy, aby dodac kontekst projektu."
            ),
        )

    def _append(self, role, text):
        colours = {"user": "#569cd6", "claude": "#4ec9b0", "system": "#808080", "error": "#f44747"}
        labels = {"user": "Ty", "claude": "AI", "system": "System", "error": "Blad"}
        colour = colours.get(role, "#ffffff")
        label = labels.get(role, role)
        parts = text.split("```")
        message_html = f'<span style="color:{colour};font-weight:bold">{label}:</span> '
        for index, part in enumerate(parts):
            if index % 2 == 1:
                escaped = html_escape_code(part)
                message_html += (
                    "<br><pre style=\"background:#2d2d2d;color:#ce9178;padding:6px;"
                    f"border-radius:4px;white-space:pre-wrap\">{escaped}</pre>"
                )
            else:
                message_html += html.escape(part).replace("\n", "<br>")
        self.chat.append(message_html + "<br>")
        self.chat.moveCursor(QTextCursor.End)

    def _inject_layers(self):
        layers = self.iface.mapCanvas().layers()
        if not layers:
            self._append("system", "Brak warstw w projekcie.")
            return
        info = "Warstwy w projekcie:\n"
        for lyr in layers:
            info += f"  - {lyr.name()} (typ: {lyr.type()}, CRS: {lyr.crs().authid()})\n"
        self.input.setText(info.strip())

    def _inject_crs(self):
        crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.input.setText(f"Aktualny CRS projektu: {crs.authid()} - {crs.description()}")

    def _clear(self):
        self.chat.clear()
        self.client.reset()
        self._welcome()

    def apply_credentials(self, provider, provider_settings, reset_chat=False):
        provider_changed = provider != self.provider
        self.provider = provider
        self.provider_settings = provider_settings
        self.client = AIClient(provider, provider_settings)
        if reset_chat or provider_changed:
            self.chat.clear()
            self._welcome()

    def _change_provider(self):
        config = self.plugin.configure_provider()
        if not config:
            return
        provider, provider_settings = config
        self.apply_credentials(provider, provider_settings, reset_chat=True)
        self._append(
            "system",
            f"Przelaczono providera na {AIClient.provider_label(provider)}. Model: {self.client.model}.",
        )

    def _change_settings(self):
        config = self.plugin.configure_provider_settings()
        if not config:
            return
        provider, provider_settings = config
        self.apply_credentials(provider, provider_settings, reset_chat=True)
        self._append(
            "system",
            f"Zaktualizowano konfiguracje dla {AIClient.provider_label(provider)}. Model: {self.client.model}.",
        )

    def _send(self):
        message = self.input.text().strip()
        if not message or (self.worker and self.worker.isRunning()):
            return
        self.input.clear()
        self.send_btn.setEnabled(False)
        provider_name = AIClient.provider_label(self.provider)
        self.status.setText(f"Czekam na odpowiedz z {provider_name}...")
        self._append("user", message)
        self.worker = Worker(self.client, message, self.tool_executor.definitions())
        self.worker.finished.connect(self._on_reply)
        self.worker.error.connect(self._on_error)
        self.worker.status.connect(self._on_status)
        self.worker.tool_requested.connect(self._handle_tool_request)
        self.worker.start()

    def _on_reply(self, reply):
        self._append("claude", reply)
        self.send_btn.setEnabled(True)
        self.status.setText("")
        self.worker = None

    def _on_error(self, err):
        self._append("error", err)
        self.send_btn.setEnabled(True)
        self.status.setText("")
        self.worker = None

    def _on_status(self, text):
        self.status.setText(text)

    def _handle_tool_request(self, tool_name, tool_args):
        args_text = json.dumps(tool_args, ensure_ascii=False) if tool_args else "{}"
        self._append("system", f"Narzedzie QGIS: {tool_name} {args_text}")
        result = self.tool_executor.execute(tool_name, tool_args)
        current_worker = self.worker
        if current_worker:
            current_worker.set_tool_result(result)


class AIAssistantPlugin:
    SETTINGS_PROVIDER_KEY = "qgis_ai_assistant/provider"
    SETTINGS_PROVIDER_CONFIG_PREFIX = "qgis_ai_assistant/provider_config"
    SETTINGS_API_KEY_PREFIX = "qgis_ai_assistant/api_key"

    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None

    def initGui(self):
        self.action = QAction("AI Assistant", self.iface.mainWindow())
        self.action.setToolTip("Otworz panel AI Assistant")
        self.action.triggered.connect(self.toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("AI Assistant", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("AI Assistant", self.action)
        if self.dock:
            self.dock.deleteLater()
            self.dock = None

    def toggle_panel(self):
        if self.dock and self.dock.isVisible():
            self.dock.hide()
            return
        config = self.ensure_provider_configuration()
        if not config:
            return
        provider, provider_settings = config
        if self.dock is None:
            panel = AIPanel(self, provider, provider_settings)
            self.dock = QDockWidget("AI Assistant", self.iface.mainWindow())
            self.dock.setObjectName("AIAssistantDock")
            self.dock.setWidget(panel)
            self.dock.setMinimumWidth(350)
            self.iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, self.dock)
        else:
            self.dock.widget().apply_credentials(provider, provider_settings)
        self.dock.show()

    def ensure_provider_configuration(self):
        provider = self._get_provider()
        provider_settings = None
        saved_settings = {}
        needs_provider_selection = not provider

        if provider:
            saved_settings = self._get_saved_provider_settings(provider)
            needs_provider_selection = AIClient.provider_configuration_needed(provider, saved_settings)
            try:
                provider_settings = AIClient.normalize_settings(provider, saved_settings)
            except ValueError:
                provider_settings = None
                needs_provider_selection = True

        if needs_provider_selection or provider_settings is None:
            provider = self._prompt_provider(provider or "lmstudio")
            if not provider:
                return None
            saved_settings = self._get_saved_provider_settings(provider)
            try:
                provider_settings = AIClient.normalize_settings(provider, saved_settings)
            except ValueError:
                provider_settings = None
            if AIClient.provider_configuration_needed(provider, saved_settings) or provider_settings is None:
                provider_settings = self._prompt_provider_settings(provider, saved_settings)
                if provider_settings is None:
                    return None
                provider_settings = self._save_provider_settings(provider, provider_settings)
            self._save_provider(provider)
        return provider, provider_settings

    def configure_provider(self):
        current_provider = self._get_provider()
        provider = self._prompt_provider(current_provider)
        if not provider:
            return None
        self._save_provider(provider)
        saved_settings = self._get_saved_provider_settings(provider)
        needs_prompt = AIClient.provider_configuration_needed(provider, saved_settings)
        try:
            provider_settings = AIClient.normalize_settings(provider, saved_settings)
        except ValueError:
            provider_settings = None
            needs_prompt = True
        if needs_prompt or provider_settings is None:
            provider_settings = self._prompt_provider_settings(provider, saved_settings)
            if provider_settings is None:
                self._save_provider(current_provider)
                return None
            provider_settings = self._save_provider_settings(provider, provider_settings)
        return provider, provider_settings

    def configure_provider_settings(self):
        provider = self._get_provider()
        saved_settings = self._get_saved_provider_settings(provider)
        provider_settings = self._prompt_provider_settings(provider, saved_settings)
        if provider_settings is None:
            return None
        provider_settings = self._save_provider_settings(provider, provider_settings)
        return provider, provider_settings

    def _get_provider(self):
        provider = str(QSettings().value(self.SETTINGS_PROVIDER_KEY, "") or "").strip()
        if provider not in AIClient.provider_ids():
            return ""
        return provider

    def _save_provider(self, provider):
        QSettings().setValue(self.SETTINGS_PROVIDER_KEY, provider)

    def _provider_setting_key(self, provider, field_id):
        return f"{self.SETTINGS_PROVIDER_CONFIG_PREFIX}/{provider}/{field_id}"

    def _get_saved_provider_settings(self, provider):
        settings = {}
        qsettings = QSettings()
        for field in AIClient.provider_setting_fields(provider):
            field_id = field["id"]
            value = qsettings.value(self._provider_setting_key(provider, field_id), None)
            if value is None and field_id == "api_key":
                value = qsettings.value(f"{self.SETTINGS_API_KEY_PREFIX}/{provider}", "")
            settings[field_id] = "" if value is None else str(value)
        return settings

    def _save_provider_settings(self, provider, settings):
        normalized = AIClient.normalize_settings(provider, settings)
        qsettings = QSettings()
        for field in AIClient.provider_setting_fields(provider):
            field_id = field["id"]
            value = normalized.get(field_id, "")
            qsettings.setValue(self._provider_setting_key(provider, field_id), value)
            if field_id == "api_key":
                qsettings.setValue(f"{self.SETTINGS_API_KEY_PREFIX}/{provider}", value)
        return normalized

    def _prompt_provider(self, current_provider):
        labels = AIClient.provider_labels()
        default_provider = current_provider if current_provider in AIClient.provider_ids() else "lmstudio"
        current_label = AIClient.provider_label(default_provider)
        current_index = labels.index(current_label) if current_label in labels else 0
        label, ok = QInputDialog.getItem(
            self.iface.mainWindow(),
            "Wybierz provider AI",
            "Dostepne API:",
            labels,
            current_index,
            False,
        )
        if not ok:
            return None
        return AIClient.provider_from_label(label)

    def _prompt_provider_settings(self, provider, existing_settings=None):
        provider_label = AIClient.provider_label(provider)
        settings = dict(existing_settings or {})
        for field in AIClient.provider_setting_fields(provider):
            current_value = settings.get(field["id"], "") or field.get("default", "")
            mode = QLineEdit.Password if field.get("secret") else QLineEdit.Normal
            value, ok = QInputDialog.getText(
                self.iface.mainWindow(),
                f"{field['label']}: {provider_label}",
                f"{field['prompt']}\n(zostanie zapamietane w ustawieniach QGIS)",
                mode,
                str(current_value),
            )
            if not ok:
                return None
            value = value.strip()
            if not value:
                value = str(field.get("default", "")).strip()
            if field["id"] == "base_url":
                value = value.rstrip("/")
            if field.get("required") and not value:
                return None
            settings[field["id"]] = value
        return AIClient.normalize_settings(provider, settings)
