import threading

from qgis.core import QgsProject, QgsVectorLayer
from qgis.PyQt.QtCore import QThread, QTimer, Qt, pyqtSignal
from qgis.PyQt.QtWidgets import QApplication, QLabel, QMenu, QStackedWidget, QVBoxLayout, QWidget

from .claude_client import AIClient
from .qgis_tools import QGISToolExecutor
from .ui_components import (
    ASSISTANT_STYLESHEET,
    ChatComposer,
    ChatHeader,
    ChatView,
    GISContextBar,
    WelcomeView,
)


class Worker(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    status = pyqtSignal(str)
    tool_requested = pyqtSignal(str, dict)

    def __init__(self, client, message, tools):
        super().__init__()
        self.client = client
        self.message = message
        self.tools = tools or []
        self._tool_event = threading.Event()
        self._tool_result = None

    def run(self):
        try:
            reply = self.client.chat(
                self.message,
                tools=self.tools,
                tool_executor=self._execute_tool,
                status_callback=self.status.emit,
            )
            self.finished.emit(reply)
        except Exception as exc:
            self.error.emit(str(exc))

    def _execute_tool(self, tool_name, tool_args):
        self._tool_result = None
        self._tool_event.clear()
        self.tool_requested.emit(tool_name, tool_args)
        if not self._tool_event.wait(300):
            raise Exception(f"Przekroczono czas oczekiwania na narzedzie: {tool_name}")
        return self._tool_result

    def set_tool_result(self, result):
        self._tool_result = result
        self._tool_event.set()


class AssistantDockWidget(QWidget):
    def __init__(self, plugin, provider, provider_settings):
        super().__init__()
        self.plugin = plugin
        self.iface = plugin.iface
        self.provider = provider
        self.provider_settings = provider_settings
        self.client = AIClient(provider, provider_settings)
        self.tool_executor = QGISToolExecutor(self.iface)
        self.worker = None
        self._selection_layer = None

        self.setObjectName("assistantRoot")
        self.setStyleSheet(ASSISTANT_STYLESHEET)

        self._build_ui()
        self._build_menus()
        self._connect_context_signals()
        self.apply_credentials(provider, provider_settings, reset_chat=False)

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        self.header = ChatHeader()
        self.header.settingsRequested.connect(self._open_settings)
        root.addWidget(self.header)

        self.content_stack = QStackedWidget()
        self.welcome_view = WelcomeView()
        self.welcome_view.suggestionTriggered.connect(self._send_prompt)
        self.chat_view = ChatView()
        self.content_stack.addWidget(self.welcome_view)
        self.content_stack.addWidget(self.chat_view)
        root.addWidget(self.content_stack, 1)

        self.context_bar = GISContextBar()
        root.addWidget(self.context_bar)

        self.status_label = QLabel("")
        self.status_label.setObjectName("assistantStatus")
        self.status_label.hide()
        root.addWidget(self.status_label)

        self.composer = ChatComposer()
        self.composer.sendRequested.connect(self._handle_send_requested)
        root.addWidget(self.composer)

    def _build_menus(self):
        self.plus_menu = QMenu(self)
        self.plus_menu.addAction("Wstaw liste warstw", self._insert_layers_context)
        self.plus_menu.addAction("Wstaw CRS projektu", self._insert_crs_context)
        self.plus_menu.addAction("Pracuj na aktywnej warstwie", self._insert_active_layer_prompt)
        self.plus_menu.addSeparator()
        self.plus_menu.addAction("Wyczysc pole", self.composer.clear)
        self.composer.set_plus_menu(self.plus_menu)

        self.history_menu = QMenu(self)
        self.history_menu.addAction("Przewin do poczatku", self.chat_view.scroll_to_top)
        self.history_menu.addAction("Przewin do konca", self.chat_view.scroll_to_bottom)
        self.history_menu.addSeparator()
        self.history_menu.addAction("Kopiuj przebieg rozmowy", self._copy_transcript)
        self.header.set_history_menu(self.history_menu)

        self.more_menu = QMenu(self)
        self.more_menu.addAction("Nowa rozmowa", self.clear_conversation)
        self.more_menu.addAction("Odswiez kontekst GIS", self._refresh_context)
        self.header.set_more_menu(self.more_menu)

    def _connect_context_signals(self):
        project = QgsProject.instance()
        project.layersAdded.connect(self._refresh_context)
        project.layersRemoved.connect(self._refresh_context)
        try:
            self.iface.currentLayerChanged.connect(self._on_current_layer_changed)
        except Exception:
            pass
        self._on_current_layer_changed(self.iface.activeLayer())

    def apply_credentials(self, provider, provider_settings, reset_chat=False):
        provider_changed = provider != self.provider
        self.provider = provider
        self.provider_settings = provider_settings
        self.client = AIClient(provider, provider_settings)
        self.header.update_session(
            AIClient.provider_label(provider),
            self.client.model,
            self.client.supports_tools(),
        )
        if reset_chat or provider_changed:
            self.clear_conversation()
        self._refresh_context()

    def clear_conversation(self):
        self.client.reset()
        self.chat_view.clear_messages()
        self.content_stack.setCurrentWidget(self.welcome_view)
        self._set_status("")
        self.composer.set_busy(False)
        self.composer.focus_input()

    def _handle_send_requested(self, raw_text):
        self._send_prompt(raw_text)

    def _send_prompt(self, prompt):
        message = (prompt or "").strip()
        if not message or (self.worker and self.worker.isRunning()):
            return

        self._refresh_context()
        self.content_stack.setCurrentWidget(self.chat_view)
        self.chat_view.add_message("user", message)
        self.composer.clear()
        self.composer.set_busy(True)
        self._set_status(f"Lacze z {AIClient.provider_label(self.provider)}...")

        self.worker = Worker(self.client, message, self.tool_executor.definitions())
        self.worker.finished.connect(self._on_reply)
        self.worker.error.connect(self._on_error)
        self.worker.status.connect(self._set_status)
        self.worker.tool_requested.connect(self._handle_tool_request)
        self.worker.start()

    def _on_reply(self, reply):
        self.chat_view.add_message("assistant", reply)
        self.worker = None
        self.composer.set_busy(False)
        self._set_status("")
        self._refresh_context()
        self.composer.focus_input()

    def _on_error(self, err):
        self.chat_view.add_message("error", err)
        self.content_stack.setCurrentWidget(self.chat_view)
        self.worker = None
        self.composer.set_busy(False)
        self._set_status("")
        self.composer.focus_input()

    def _handle_tool_request(self, tool_name, tool_args):
        result = self.tool_executor.execute(tool_name, tool_args)
        if self.worker:
            self.worker.set_tool_result(result)
        self._refresh_context()

    def _set_status(self, text):
        message = (text or "").strip()
        self.status_label.setText(message)
        self.status_label.setVisible(bool(message))

    def _open_settings(self):
        config = self.plugin.open_settings_dialog(self.provider)
        if not config:
            return
        provider, provider_settings = config
        provider_changed = provider != self.provider
        self.apply_credentials(provider, provider_settings, reset_chat=provider_changed)
        if self.chat_view.has_messages():
            self.chat_view.add_message(
                "system",
                f"Zaktualizowano ustawienia sesji. Provider: {AIClient.provider_label(provider)}. Model: {self.client.model}.",
            )

    def _copy_transcript(self):
        QApplication.clipboard().setText(self.chat_view.transcript_text())
        self._set_status("Skopiowano przebieg rozmowy.")
        QTimer.singleShot(1800, lambda: self._set_status(""))

    def _refresh_context(self, *_args):
        layer = self.iface.activeLayer()
        layer_name = layer.name() if layer else "Brak aktywnej warstwy"
        crs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        selected_count = layer.selectedFeatureCount() if isinstance(layer, QgsVectorLayer) else 0
        self.context_bar.set_context(layer_name, crs, selected_count)

    def _on_current_layer_changed(self, layer=None):
        if self._selection_layer and isinstance(self._selection_layer, QgsVectorLayer):
            try:
                self._selection_layer.selectionChanged.disconnect(self._refresh_context)
            except Exception:
                pass

        self._selection_layer = layer if isinstance(layer, QgsVectorLayer) else None
        if self._selection_layer:
            try:
                self._selection_layer.selectionChanged.connect(self._refresh_context)
            except Exception:
                pass
        self._refresh_context()

    def _insert_layers_context(self):
        layers = self.iface.mapCanvas().layers()
        if not layers:
            self.composer.set_text("W projekcie nie ma obecnie warstw. Powiedz, co przygotowac dalej.")
            self.composer.focus_input()
            return

        lines = ["Warstwy w projekcie:"]
        for layer in layers:
            lines.append(
                f"- {layer.name()} (CRS: {layer.crs().authid()})"
            )
        self.composer.set_text("\n".join(lines))
        self.composer.focus_input()

    def _insert_crs_context(self):
        crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.composer.set_text(
            f"Aktualny CRS projektu: {crs.authid()} - {crs.description()}. "
            "Przeanalizuj, czy jest odpowiedni do tej pracy."
        )
        self.composer.focus_input()

    def _insert_active_layer_prompt(self):
        layer = self.iface.activeLayer()
        if not layer:
            self.composer.set_text("W projekcie nie ma aktywnej warstwy. Podpowiedz, od czego zaczac.")
        else:
            self.composer.set_text(
                f"Pracuj na aktywnej warstwie '{layer.name()}'. "
                "Podpowiedz kolejne kroki analizy i odpowiednie narzedzia QGIS."
            )
        self.composer.focus_input()
