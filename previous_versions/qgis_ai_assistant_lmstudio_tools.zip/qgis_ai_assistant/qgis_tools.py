import copy

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsWkbTypes,
)


class QGISToolExecutor:
    TOOL_DEFINITIONS = [
        {
            "type": "function",
            "function": {
                "name": "list_layers",
                "description": (
                    "Zwraca wszystkie warstwy zaladowane w projekcie QGIS wraz z ich "
                    "typem, CRS, liczba obiektow i podstawowymi metadanymi."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_layer_details",
                "description": (
                    "Zwraca szczegoly jednej warstwy po nazwie: typ, CRS, pola, "
                    "geometrie, liczbe obiektow i zasieg."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "layer_name": {
                            "type": "string",
                            "description": "Nazwa warstwy w projekcie QGIS.",
                        }
                    },
                    "required": ["layer_name"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_project_crs",
                "description": "Zwraca aktualny CRS projektu QGIS.",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_selected_features_count",
                "description": (
                    "Zwraca liczbe zaznaczonych obiektow w warstwie wektorowej."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "layer_name": {
                            "type": "string",
                            "description": "Nazwa warstwy wektorowej.",
                        }
                    },
                    "required": ["layer_name"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "run_buffer",
                "description": (
                    "Tworzy nowa warstwe bufora dla warstwy wektorowej i dodaje "
                    "wynik do projektu QGIS."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "layer_name": {
                            "type": "string",
                            "description": "Nazwa warstwy wektorowej.",
                        },
                        "distance": {
                            "type": "number",
                            "description": "Odleglosc bufora w jednostkach warstwy.",
                        },
                        "segments": {
                            "type": "integer",
                            "description": "Liczba segmentow zaokraglenia bufora.",
                            "default": 8,
                        },
                        "dissolve": {
                            "type": "boolean",
                            "description": "Czy scalic wszystkie bufory.",
                            "default": False,
                        },
                        "output_name": {
                            "type": "string",
                            "description": "Opcjonalna nazwa nowej warstwy wynikowej.",
                        },
                    },
                    "required": ["layer_name", "distance"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "run_reproject_layer",
                "description": (
                    "Tworzy nowa warstwe przetransformowana do docelowego CRS i "
                    "dodaje wynik do projektu QGIS."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "layer_name": {
                            "type": "string",
                            "description": "Nazwa warstwy wektorowej.",
                        },
                        "target_crs": {
                            "type": "string",
                            "description": "Docelowy CRS, np. EPSG:2180 albo EPSG:3857.",
                        },
                        "output_name": {
                            "type": "string",
                            "description": "Opcjonalna nazwa nowej warstwy wynikowej.",
                        },
                    },
                    "required": ["layer_name", "target_crs"],
                },
            },
        },
    ]

    def __init__(self, iface):
        self.iface = iface

    def definitions(self):
        return copy.deepcopy(self.TOOL_DEFINITIONS)

    def execute(self, tool_name, arguments=None):
        arguments = arguments or {}
        handlers = {
            "list_layers": self.list_layers,
            "get_layer_details": self.get_layer_details,
            "get_project_crs": self.get_project_crs,
            "get_selected_features_count": self.get_selected_features_count,
            "run_buffer": self.run_buffer,
            "run_reproject_layer": self.run_reproject_layer,
        }

        handler = handlers.get(tool_name)
        if not handler:
            return {
                "ok": False,
                "tool": tool_name,
                "error": f"Nieznane narzedzie: {tool_name}",
            }

        try:
            result = handler(**arguments)
            if not isinstance(result, dict):
                result = {"result": result}
            result.setdefault("ok", True)
            result.setdefault("tool", tool_name)
            return result
        except Exception as exc:
            return {
                "ok": False,
                "tool": tool_name,
                "arguments": arguments,
                "error": str(exc),
            }

    def list_layers(self):
        layers = []
        for layer in QgsProject.instance().mapLayers().values():
            layers.append(self._layer_summary(layer))
        return {
            "count": len(layers),
            "layers": layers,
        }

    def get_layer_details(self, layer_name):
        layer = self._get_layer_by_name(layer_name)
        details = self._layer_summary(layer)
        if isinstance(layer, QgsVectorLayer):
            details["fields"] = [
                {
                    "name": field.name(),
                    "type": field.typeName(),
                    "length": field.length(),
                    "precision": field.precision(),
                }
                for field in layer.fields()
            ]
        elif isinstance(layer, QgsRasterLayer):
            details["band_count"] = layer.bandCount()
            details["width"] = layer.width()
            details["height"] = layer.height()
        return {
            "layer": details,
        }

    def get_project_crs(self):
        crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        return {
            "project_crs": {
                "authid": crs.authid(),
                "description": crs.description(),
                "is_geographic": crs.isGeographic(),
            },
            "layer_count": len(QgsProject.instance().mapLayers()),
        }

    def get_selected_features_count(self, layer_name):
        layer = self._get_vector_layer(layer_name)
        return {
            "layer_name": layer.name(),
            "selected_features_count": layer.selectedFeatureCount(),
            "total_features_count": layer.featureCount(),
        }

    def run_buffer(
        self,
        layer_name,
        distance,
        segments=8,
        dissolve=False,
        output_name="",
    ):
        layer = self._get_vector_layer(layer_name)
        processing = self._processing_module()
        before_ids = set(QgsProject.instance().mapLayers().keys())

        processing.runAndLoadResults(
            "native:buffer",
            {
                "INPUT": layer,
                "DISTANCE": float(distance),
                "SEGMENTS": int(segments),
                "END_CAP_STYLE": 0,
                "JOIN_STYLE": 0,
                "MITER_LIMIT": 2.0,
                "DISSOLVE": bool(dissolve),
                "OUTPUT": "memory:",
            },
        )

        output_layer = self._find_new_vector_layer(before_ids)
        if output_name:
            output_layer.setName(output_name)

        return {
            "source_layer": layer.name(),
            "output_layer": output_layer.name(),
            "output_layer_id": output_layer.id(),
            "feature_count": output_layer.featureCount(),
            "crs": output_layer.crs().authid(),
            "geometry_type": QgsWkbTypes.displayString(output_layer.wkbType()),
        }

    def run_reproject_layer(self, layer_name, target_crs, output_name=""):
        layer = self._get_vector_layer(layer_name)
        target = QgsCoordinateReferenceSystem(target_crs)
        if not target.isValid():
            raise Exception(f"Niepoprawny CRS docelowy: {target_crs}")

        processing = self._processing_module()
        before_ids = set(QgsProject.instance().mapLayers().keys())

        processing.runAndLoadResults(
            "native:reprojectlayer",
            {
                "INPUT": layer,
                "TARGET_CRS": target,
                "OUTPUT": "memory:",
            },
        )

        output_layer = self._find_new_vector_layer(before_ids)
        if output_name:
            output_layer.setName(output_name)

        return {
            "source_layer": layer.name(),
            "output_layer": output_layer.name(),
            "output_layer_id": output_layer.id(),
            "source_crs": layer.crs().authid(),
            "target_crs": output_layer.crs().authid(),
            "feature_count": output_layer.featureCount(),
        }

    def _layer_summary(self, layer):
        details = {
            "id": layer.id(),
            "name": layer.name(),
            "crs": layer.crs().authid(),
            "extent": self._extent_to_dict(layer.extent()),
        }
        if isinstance(layer, QgsVectorLayer):
            details.update(
                {
                    "layer_type": "vector",
                    "provider_type": layer.providerType(),
                    "geometry_type": QgsWkbTypes.displayString(layer.wkbType()),
                    "feature_count": layer.featureCount(),
                    "selected_feature_count": layer.selectedFeatureCount(),
                }
            )
        elif isinstance(layer, QgsRasterLayer):
            details.update(
                {
                    "layer_type": "raster",
                    "provider_type": layer.providerType(),
                    "band_count": layer.bandCount(),
                    "width": layer.width(),
                    "height": layer.height(),
                }
            )
        else:
            details["layer_type"] = "unknown"
        return details

    def _extent_to_dict(self, extent):
        return {
            "xmin": extent.xMinimum(),
            "ymin": extent.yMinimum(),
            "xmax": extent.xMaximum(),
            "ymax": extent.yMaximum(),
        }

    def _get_layer_by_name(self, layer_name):
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers:
            raise Exception(f"Nie znaleziono warstwy o nazwie: {layer_name}")
        return layers[0]

    def _get_vector_layer(self, layer_name):
        layer = self._get_layer_by_name(layer_name)
        if not isinstance(layer, QgsVectorLayer):
            raise Exception(f"Warstwa '{layer_name}' nie jest warstwa wektorowa.")
        return layer

    def _find_new_vector_layer(self, before_ids):
        new_layers = [
            layer
            for layer_id, layer in QgsProject.instance().mapLayers().items()
            if layer_id not in before_ids and isinstance(layer, QgsVectorLayer)
        ]
        if not new_layers:
            raise Exception("Algorytm nie dodal nowej warstwy wynikowej do projektu.")
        return new_layers[-1]

    def _processing_module(self):
        try:
            import processing
        except ImportError as exc:
            raise Exception("Modul QGIS Processing nie jest dostepny.") from exc
        return processing
