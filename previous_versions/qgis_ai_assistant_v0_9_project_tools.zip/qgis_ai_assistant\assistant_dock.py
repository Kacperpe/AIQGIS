import html
import json
import threading

from qgis.PyQt.QtCore import QThread, pyqtSignal
from qgis.PyQt.QtGui import QTextCursor
from qgis.PyQt.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .claude_client import AIClient
from .qgis_tools import QGISToolExecutor


def html_escape_code(text):
    code = text.strip("\n")
    if "\n" in code:
        first_line, rest = code.split("\n", 1)
        if first_line.isidentifier():
            code = rest
    return html.escape(code)


class Worker(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    status = pyqtSignal(str)
    tool_requested = pyqtSignal(str, dict)

    def __init__(self, client, message, tools):
        super().__init__()
        self.client = client
        self.message = message
        self.tools = tools or []
        self._tool_event = threading.Event()
        self._tool_result = None

    def run(self):
        try:
            reply = self.client.chat(
                self.message,
                tools=self.tools,
                tool_executor=self._execute_tool,
                status_callback=self.status.emit,
            )
            self.finished.emit(reply)
        except Exception as exc:
            self.error.emit(str(exc))

    def _execute_tool(self, tool_name, tool_args):
        self._tool_result = None
        self._tool_event.clear()
        self.tool_requested.emit(tool_name, tool_args)
        if not self._tool_event.wait(300):
            raise Exception(f"Przekroczono czas oczekiwania na narzedzie: {tool_name}")
        return self._tool_result

    def set_tool_result(self, result):
        self._tool_result = result
        self._tool_event.set()


class AssistantDockWidget(QWidget):
    def __init__(self, plugin, provider, provider_settings):
        super().__init__()
        self.plugin = plugin
        self.iface = plugin.iface
        self.provider = provider
        self.provider_settings = provider_settings
        self.client = AIClient(provider, provider_settings)
        self.tool_executor = QGISToolExecutor(self.iface)
        self.worker = None

        self._build_ui()
        self._welcome()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(4)

        self.chat = QTextEdit()
        self.chat.setReadOnly(True)
        self.chat.setStyleSheet(
            "QTextEdit { background:#1e1e1e; color:#d4d4d4; "
            "font-family: Consolas, monospace; font-size:12px; }"
        )
        root.addWidget(self.chat)

        buttons_row = QHBoxLayout()
        buttons_row.setSpacing(4)
        for label, slot in [
            ("Provider", self._change_provider),
            ("Ustawienia", self._change_settings),
            ("Warstwy", self._inject_layers),
            ("CRS", self._inject_crs),
            ("Wyczysc", self._clear),
        ]:
            button = QPushButton(label)
            button.clicked.connect(slot)
            buttons_row.addWidget(button)
        root.addLayout(buttons_row)

        send_row = QHBoxLayout()
        send_row.setSpacing(4)

        self.input = QLineEdit()
        self.input.setPlaceholderText("Zadaj pytanie o dane GIS...")
        self.input.returnPressed.connect(self._send)

        self.send_btn = QPushButton("Wyslij")
        self.send_btn.setFixedWidth(90)
        self.send_btn.clicked.connect(self._send)

        send_row.addWidget(self.input)
        send_row.addWidget(self.send_btn)
        root.addLayout(send_row)

        self.status = QLabel("")
        self.status.setStyleSheet("color: gray; font-size: 10px;")
        root.addWidget(self.status)

    def _welcome(self):
        provider_name = AIClient.provider_label(self.provider)
        tools_state = (
            "Toole QGIS aktywne."
            if self.client.supports_tools()
            else "Toole QGIS nieaktywne dla tego providera."
        )
        self._append(
            "system",
            (
                f"AI Assistant gotowy. Provider: {provider_name}. "
                f"Model: {self.client.model}. {tools_state} "
                "Kliknij Warstwy, aby dodac kontekst projektu."
            ),
        )
        self.input.setFocus()

    def _append(self, role, text):
        colours = {
            "user": "#569cd6",
            "assistant": "#4ec9b0",
            "system": "#808080",
            "error": "#f44747",
        }
        labels = {
            "user": "Ty",
            "assistant": "AI",
            "system": "System",
            "error": "Blad",
        }
        colour = colours.get(role, "#ffffff")
        label = labels.get(role, role)
        parts = (text or "").split("```")
        message_html = f'<span style="color:{colour};font-weight:bold">{label}:</span> '

        for index, part in enumerate(parts):
            if index % 2 == 1:
                escaped = html_escape_code(part)
                message_html += (
                    "<br><pre style=\"background:#2d2d2d;color:#ce9178;padding:6px;"
                    f"border-radius:4px;white-space:pre-wrap\">{escaped}</pre>"
                )
            else:
                message_html += html.escape(part).replace("\n", "<br>")

        self.chat.append(message_html + "<br>")
        self.chat.moveCursor(QTextCursor.End)

    def _inject_layers(self):
        layers = self.iface.mapCanvas().layers()
        if not layers:
            self._append("system", "Brak warstw w projekcie.")
            return

        info = ["Warstwy w projekcie:"]
        for layer in layers:
            info.append(f"  - {layer.name()} (typ: {layer.type()}, CRS: {layer.crs().authid()})")
        self.input.setText("\n".join(info))

    def _inject_crs(self):
        crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        self.input.setText(f"Aktualny CRS projektu: {crs.authid()} - {crs.description()}")

    def _clear(self):
        if self.worker and self.worker.isRunning():
            return
        self.chat.clear()
        self.client.reset()
        self.status.setText("")
        self._welcome()

    def apply_credentials(self, provider, provider_settings, reset_chat=False):
        provider_changed = provider != self.provider
        self.provider = provider
        self.provider_settings = provider_settings
        self.client = AIClient(provider, provider_settings)
        if reset_chat or provider_changed:
            self.chat.clear()
            self.status.setText("")
            self._welcome()

    def _change_provider(self):
        if self.worker and self.worker.isRunning():
            return

        config = self.plugin.configure_provider()
        if not config:
            return
        provider, provider_settings = config
        self.apply_credentials(provider, provider_settings, reset_chat=True)
        self._append(
            "system",
            f"Przelaczono providera na {AIClient.provider_label(provider)}. Model: {self.client.model}.",
        )

    def _change_settings(self):
        if self.worker and self.worker.isRunning():
            return

        config = self.plugin.configure_provider_settings()
        if not config:
            return
        provider, provider_settings = config
        self.apply_credentials(provider, provider_settings, reset_chat=True)
        self._append(
            "system",
            f"Zaktualizowano konfiguracje dla {AIClient.provider_label(provider)}. Model: {self.client.model}.",
        )

    def _send(self):
        message = self.input.text().strip()
        if not message or (self.worker and self.worker.isRunning()):
            return

        self.input.clear()
        self.send_btn.setEnabled(False)
        provider_name = AIClient.provider_label(self.provider)
        self.status.setText(f"Czekam na odpowiedz z {provider_name}...")
        self._append("user", message)

        self.worker = Worker(self.client, message, self.tool_executor.definitions())
        self.worker.finished.connect(self._on_reply)
        self.worker.error.connect(self._on_error)
        self.worker.status.connect(self._on_status)
        self.worker.tool_requested.connect(self._handle_tool_request)
        self.worker.start()

    def _on_reply(self, reply):
        self._append("assistant", reply)
        self.send_btn.setEnabled(True)
        self.status.setText("")
        self.worker = None
        self.input.setFocus()

    def _on_error(self, err):
        self._append("error", err)
        self.send_btn.setEnabled(True)
        self.status.setText("")
        self.worker = None
        self.input.setFocus()

    def _on_status(self, text):
        self.status.setText(text)

    def _handle_tool_request(self, tool_name, tool_args):
        args_text = json.dumps(tool_args, ensure_ascii=False) if tool_args else "{}"
        self._append("system", f"Narzedzie QGIS: {tool_name} {args_text}")
        result = self.tool_executor.execute(tool_name, tool_args)
        current_worker = self.worker
        if current_worker:
            current_worker.set_tool_result(result)
